﻿using CsvHelper;
using System.ComponentModel.Design;
using System.Globalization;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool menu = true;
            while (menu)
            {
                Console.WriteLine("1. Wyświetl osobę\n2. Dodaj osobę\n3. Modyfikuj osobę\n5. Wyjście");
                int userInput = Convert.ToInt32(Console.ReadLine());

                string filePath = "sample.csv";

                switch (userInput)
                {
                    default:
                        Console.WriteLine("Nie wybrano żadnej pozycji, spróbuj ponownie");
                        break;
                    case 1:
                        Console.WriteLine("Wyświetl osobę");
                        ReadAndDisplayDataFromCsv(filePath);
                        break;
                    case 2:
                        Console.WriteLine("Dodaj osobę");
                        WriteDataToCsv(filePath);
                        break;
                    case 3:
                        Console.WriteLine("Modyfikuj osobę");
                        break;

                    case 4:
                        Console.WriteLine("Usuń osobę");

                        break;
                    case 5:
                        Console.WriteLine("Wyjście");
                        menu = false;
                        break;
                }
            }

            static void WriteDataToCsv(string filePath)
            {
                Console.WriteLine("Wpisz imię");
                string fName = Console.ReadLine();
                Console.WriteLine("Wpisz imię");
                string lName = Console.ReadLine();
                Console.WriteLine("Wpisz wiek");
                int age = Convert.ToInt32(Console.ReadLine());

                List<Person> people = new List<Person>
                {
                    new Person { FirstName = fName, LastName = lName, Age = age }
                };

                using (var writer = new StreamWriter(filePath))
                using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                {
                    csv.WriteRecords(people);
                }

                Console.WriteLine("Dane zapisane do pliku CSV.");
            }

            static void ReadAndDisplayDataFromCsv(string filePath)
            {
                using (var reader = new StreamReader(filePath))
                using (var csv = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    var records = csv.GetRecords<Person>().ToList();

                    Console.WriteLine("\nDane odczytane z pliku CSV:");
                    foreach (var person in records)
                    {
                        Console.WriteLine($"Imię: {person.FirstName}, Nazwisko: {person.LastName}, Wiek: {person.Age}");
                    }
                }
            }
        }
    }
}